# Núcleo PC — loja de computadores e peças

Este é um projeto de Programação Web feito com PHP, HTML, CSS, JavaScript e MySQL. Ele tem duas partes: a loja que o cliente usa e o painel para administrar a loja física.

## O que tem no projeto

- `loja/`: catálogo, detalhes dos produtos, carrinho, conta do cliente e pedidos.
- `admin/`: painel de administração, produtos, categorias, fornecedores, estoque e vendas.
- `uploads/produtos/`: imagens dos produtos.
- `database/schema.sql`: script para criar o banco de dados.

O projeto usa MVC para separar as partes principais:

- **Model:** conversa com o banco e trabalha com os dados.
- **View:** mostra a página HTML.
- **Controller:** recebe a ação do usuário e chama o Model ou a View.

## Como executar no XAMPP

1. Copie a pasta `nucleopc` para `C:\xampp\htdocs\`.
2. Abra o XAMPP e ligue **Apache** e **MySQL**.
3. Entre em `http://localhost/phpmyadmin`.
4. Use a opção **Importar** e selecione `database/schema.sql`.
5. Confira os dados de conexão em `admin/config/Database.php` e `loja/config/Database.php`. No XAMPP padrão, o usuário costuma ser `root` e a senha fica vazia.
6. Abra a loja em `http://localhost/nucleopc/loja/` e o painel em `http://localhost/nucleopc/admin/`.

## Onde começar a estudar o código

- `loja/index.php` e `admin/index.php`: pontos de entrada dos sistemas.
- `core/App.php`: entende a URL e chama a página certa.
- `controllers/`: contém as ações, como listar ou cadastrar.
- `models/`: contém o trabalho com os dados.
- `views/`: contém o HTML das páginas.
- `assets/css/` e `assets/js/`: estilos e interações do site.

## Antes de apresentar ou publicar

Teste login, cadastro, carrinho, pedidos, cadastro de produtos e permissões do painel. A verificação de sintaxe do PHP não garante que o banco esteja configurado nem que todos os fluxos funcionem. Não publique senhas reais, chaves de pagamento ou dados pessoais no código. Se o pagamento estiver configurado como demonstração, explique isso na apresentação.

Os comentários foram escritos para ajudar a entender a função de cada arquivo. A lógica principal foi mantida para evitar mudanças inesperadas no funcionamento e no visual.

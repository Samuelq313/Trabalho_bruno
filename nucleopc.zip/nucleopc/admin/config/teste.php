<?php
return [
    'host' => 'sql112.infinityfree.com',
    'name' => 'if0_43312213_XXX',
    'user' => 'if0_43312213',
    'pass' => 'CioY5NZI5XiB5Bw',
];
